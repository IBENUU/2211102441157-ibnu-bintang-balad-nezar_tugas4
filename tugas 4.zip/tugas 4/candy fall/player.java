import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class player extends Actor
{
    /**
     * Act - do whatever the player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int count = 0;
    
    void dimakan() {
        Counter.add(1);
        getWorld().removeObject(this);
    }
    public player(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/8;
        int myNewWidth = (int)myImage.getWidth()/8;
        myImage.scale(myNewWidth, myNewHeight);
    }
    public void act()
    {
        if(Greenfoot.isKeyDown("d")){
            setLocation(getX()+3, getY());
        }
        if(Greenfoot.isKeyDown("a")){
            setLocation(getX()-3, getY());
        }
        if(isTouching(thrash.class)){
            Counter2.add(-1);
            dimakan();
        }
        if(Counter2.value==0){
            Greenfoot.delay(1);
            Greenfoot.setWorld(new GameOver());
            getWorld().removeObject(this);
        }
    }
}
