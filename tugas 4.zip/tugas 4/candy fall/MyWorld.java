import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(300, 500, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        th1 th1 = new th1();
        addObject(th1,204,210);
        th1.setLocation(143,207);
        th2 th2 = new th2();
        addObject(th2,242,238);
        candy1 candy1 = new candy1();
        addObject(candy1,86,104);
        candy1.setLocation(59,64);
        th1.setLocation(86,161);
        th2.setLocation(227,181);
        th2.setLocation(222,141);
        candy2 candy2 = new candy2();
        addObject(candy2,292,175);
        candy2.setLocation(280,177);
        candy3 candy3 = new candy3();
        addObject(candy3,54,202);
        candy2 candy22 = new candy2();
        addObject(candy22,195,4);
        candy22.setLocation(195,45);
        candy22.setLocation(197,39);
        removeObject(candy22);
        candy2.setLocation(255,105);
        th2.setLocation(163,82);
        th1.setLocation(155,160);
        candy3.setLocation(43,158);
        th1.setLocation(119,146);
        th2.setLocation(235,30);
        th1.setLocation(135,114);
        player player = new player();
        addObject(player,195,383);
        player.setLocation(143,424);
        Counter counter = new Counter("");
        addObject(counter,47,479);
        Counter2 counter2 = new Counter2("HP :");
        addObject(counter2,251,481);
    }
}
