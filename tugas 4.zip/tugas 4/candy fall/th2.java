import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class th2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class th2 extends thrash
{
    /**
     * Act - do whatever the th2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    void cetakbaru(){
        th2 th2 = new th2();
        getWorld().addObject(th2,Greenfoot.getRandomNumber(300),0);
    }
    void maju(){
        setLocation(getX(), getY()+2);
    }
    
    public void act()
    {
        super.act();
    }
}
